Provided is the HTML file "index.html" and its asscociated stylesheet, style.css.

To run this program, python needs to be installed to host the application, and a Google Developer account with an Calendar API key is needed.

Areas where your own keys need to be entered have been marked with comments.

For a detailed startup guide, see the readme on the projects github, at https://github.com/wbosley/Scheduler 